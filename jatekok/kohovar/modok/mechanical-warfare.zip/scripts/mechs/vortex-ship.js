const elib = require("mechanical-warfare/effectlib");
const plib = require("mechanical-warfare/plib");
const bulletLib = require("mechanical-warfare/bulletlib");

const vortexBullet = bulletLib.bullet(BasicBulletType, 6, 6, 0, 0.01, 100, 0, -1, 0, 6, 60, cons(b => {
	elib.fillCircle(b.x, b.y, vortexBullet.frontColor, 1, vortexBullet.bulletWidth);
	elib.outlineCircle(b.x, b.y, vortexBullet.backColor, 1, vortexBullet.bulletWidth);
}), cons(b => {
	if(!Vars.state.isPaused()){
		if(b.timer.get(0, 3)){
			Effects.effect(vortexBullet.trailEffectA, b.x, b.y, b.rot());
		}
		Effects.effect(vortexBullet.trailEffectB, b.x, b.y, b.rot());
	}
}), null, null, null);
vortexBullet.bulletWidth = vortexBullet.bulletHeight = 6;
vortexBullet.frontColor = plib.frontColorPurple;
vortexBullet.backColor = plib.backColorPurple;
vortexBullet.shootEffect = Fx.shootBig;
vortexBullet.smokeEffect = Fx.shootBigSmoke;
vortexBullet.trailEffectA = newEffect(30, e => {
	elib.fillCircle(e.x, e.y, vortexBullet.backColor, 1, 0.2 + e.fout() * 4.8);
});
vortexBullet.trailEffectB = newEffect(48, e => {
	var angle = (Time.time() + Mathf.randomSeed(e.id, 360)) % 360;
	var dist = vortexBullet.bulletWidth + 1 - e.fout() * 1.5;
	elib.fillCircle(e.x + Angles.trnsx(angle, dist), e.y + Angles.trnsy(angle, dist), vortexBullet.backColor, 1, e.fout() * 1.1);
});
vortexBullet.hitEffect = newEffect(18, e => {
	elib.fillCircle(e.x, e.y, vortexBullet.frontColor, 0.2 + e.fin() * 0.8, 0.2 + e.fout() * 11.8);
	
	e.scaled(1.2, cons(i => {
		thickness = 0.5 + i.fout() * 2.5;
		radius = i.fin() * 15;
		elib.outlineCircle(e.x, e.y, vortexBullet.backColor, thickness, radius);
	}));
});
vortexBullet.despawnEffect = vortexBullet.hitEffect;

const vortexLance = extendContent(Weapon, "vortex-lance", {
	load(){
		this.region = Core.atlas.find("clear");
	}
});
vortexLance.shots = 1;
vortexLance.shake = 1;
vortexLance.width = 0;
vortexLance.alternate = true;
vortexLance.reload = 50;
vortexLance.recoil = 2;
vortexLance.inaccuracy = 3;
vortexLance.ejectEffect = Fx.shellEjectBig;
vortexLance.shootSound = Sounds.shootBig;
vortexLance.bullet = vortexBullet;

const vortex = extendContent(Mech, "vortex-ship", {
	load(){
		this.weapon.load();
		this.region = Core.atlas.find(this.name);
	},
	draw(player){
		this.pl1.trns(player.rotation - 90, 0, -(this.weapon.getRecoil(player, true) + this.weapon.getRecoil(player, false)));
		Draw.rect(Core.atlas.find("mechanical-warfare-vortex-lance-equip"), player.x + this.pl1.x, player.y + this.pl1.y, player.rotation - 90);
		
		if(player.shootHeat > 0.01){
			Draw.color(Color.black, this.engineColor, player.shootHeat / 3);
			Draw.blend(Blending.additive);
			for(var i = 0; i < 3; i++){
				var rot = (Time.time() * this.shieldRotSpeed[i]) % 360;
				Draw.rect(Core.atlas.find(this.name + "-shield" + i), player.x, player.y, rot);
			}
			Draw.blend();
			Draw.color();
		}
    if(!Vars.state.isPaused()){
		  Draw.blend(Blending.additive);
		  Effects.effect(this.trailEffect, player.x, player.y, player.rotation);
		  Draw.blend();
    }
	},
	getExtraArmor: function(player){
		return player.shootHeat * 60;
	}
});
vortex.shieldRotSpeed = [20, 50, 100];
vortex.pl1 = new Vec2();
vortex.flying = true;
vortex.drillPower = 6;
vortex.mineSpeed = 1.6;
vortex.speed = 0.3;
vortex.maxSpeed = 4.33;
vortex.drag = 0.01;
vortex.mass = 4.5;
vortex.health = 420;
vortex.itemCapacity = 50;
vortex.engineColor = plib.engineColorPurple;
vortex.cellTrnsY = 2;
vortex.buildPower = 1.2;
vortex.weapon = vortexLance;
vortex.trailEffect = newEffect(20, e => {
	var angle = Mathf.randomSeed(e.id, 360);
	var offset = 0.3 + e.fin() * 0.4;
	Draw.color(vortex.engineColor);
	Draw.alpha(e.fout() * 0.67);
	Draw.rect(Core.atlas.find("mechanical-warfare-vortex-ship-trail"), e.x + Angles.trnsx(angle, offset), e.y + Angles.trnsy(angle, offset), e.rotation - 90);
	Draw.color();
});

const vortexPad = extendContent(MechPad, "vortex-ship-pad", {});
vortexPad.mech = vortex;
